<?php

namespace bizley\podium\models;

use bizley\podium\models\db\PostThumbActiveRecord;

/**
 * PostThumb model
 *
 * @author Paweł Bizley Brzozowski <pawel@positive.codes>
 * @since 0.1
 */
class PostThumb extends PostThumbActiveRecord {}
