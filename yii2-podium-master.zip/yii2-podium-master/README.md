# yii2-podium

This project is abandoned in favour of new Podium that is split into [Podium API](https://github.com/bizley/yii2-podium-api) 
and [Podium client](https://github.com/bizley/yii2-podium-client).

--

[Podium README](old_README.md)
